﻿# GlassDock TopBar 0.1.4 — Windows 11 x64

전체 압축을 푼 다음 GlassDock.TopBar.exe를 실행하세요. .NET 런타임이 포함되어 있어 별도 설치나 빌드가 필요하지 않습니다. EXE와 같은 폴더의 DLL과 런타임 파일을 함께 보관하세요. 기존 상단 바가 켜져 있다면 먼저 종료하세요.

새 기능: 상단 바가 켜져 있는 동안 Windows 키를 누르면 기본 시작 메뉴 대신 화면 가운데에 유리 시작 화면(검색창과 앱 범주)이 열립니다. 다시 누르면 닫힙니다. Win+E 같은 조합 키는 그대로 동작하고, 기본 시작 메뉴는 Ctrl+Esc로 열 수 있습니다.

상단 바가 켜져 있는 동안 Windows 작업 표시줄은 완전히 숨겨지고 그 자리는 화면으로 쓰입니다. 앱 실행·전환은 GlassDock 독이나 유리 시작 화면을 사용하세요. 상단 바를 종료하면 작업 표시줄, 원래 자동 숨기기 설정, Windows 키 동작이 모두 원래대로 돌아옵니다. 강제 종료돼도 복구 감시가 작업 표시줄을 되돌리고, 그것도 실패하면 다음 로그온이나 다음 실행 때 되돌립니다.

상단 바 우클릭 메뉴에서 모니터 변경과 종료가 가능합니다. Windows 트레이의 GlassDock 상단 바 메뉴에도 표시·종료 항목이 있습니다. 자동 시작은 등록하지 않습니다.

일반 창·바탕화면에서는 투명하게 표시하고 최대화·전체 화면에서는 숨깁니다. 복원·최소화하면 돌아옵니다. 최대화 중 위쪽 가장자리에 마우스를 약 0.4초 올려 잠시 표시할 수 있습니다.

이 버전은 미리보기 배포본입니다. 관리자 권한 창이 맨 앞에 있을 때의 Windows 키 동작, 보조 모니터, 다른 PC는 검증하지 않았습니다. RELEASE_NOTES.md를 확인하세요. 카카오톡 자체 알림은 각 PC에서 카카오톡 설정 → 알림 → 표시 위치 → 화면 우상단으로 선택해야 합니다.

설정은 %LOCALAPPDATA%\GlassDock\topbar.json, 오류 기록은 같은 폴더의 topbar-errors.log에 생성됩니다. 작업 표시줄 원래 설정 기록은 같은 폴더의 taskbar-state.json이며 정상 종료 시 삭제됩니다. 개인 설정·로그·대화 데이터는 이 ZIP에 포함하지 않았습니다.

소스와 전체 문서: https://github.com/SeA9612/windows11-top-bar-mac-UI
릴리즈: https://github.com/SeA9612/windows11-top-bar-mac-UI/releases/tag/v0.1.4



SHA256SUMS.txt contains the SHA-256 checksums for all files in this folder.
