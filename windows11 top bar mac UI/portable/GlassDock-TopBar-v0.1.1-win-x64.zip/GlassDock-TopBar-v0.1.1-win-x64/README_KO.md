﻿# GlassDock TopBar 0.1.1 — Windows 11 x64

전체 압축을 푼 다음 GlassDock.TopBar.exe를 실행하세요. .NET 런타임이 포함되어 있어 별도 설치나 빌드가 필요하지 않습니다. EXE와 같은 폴더의 DLL과 런타임 파일을 함께 보관하세요. 기존 상단 바가 켜져 있다면 먼저 종료하세요.

상단 바 우클릭 메뉴에서 모니터 변경과 종료가 가능합니다. Windows 트레이의 GlassDock 상단 바 메뉴에도 표시·종료 항목이 있습니다. 자동 시작은 등록하지 않습니다.

일반 창·바탕화면에서는 투명하게 표시하고 최대화·전체 화면에서는 숨깁니다. 복원·최소화하면 돌아옵니다. 최대화 중 위쪽 가장자리에 마우스를 약 0.4초 올려 잠시 표시할 수 있습니다.

이 버전은 미리보기 배포본입니다. 트레이 유리 아이콘 렌더링 오류가 남아 있고 최신 실제 알림 수신·배치 검증은 완료하지 못했습니다. RELEASE_NOTES.md를 확인하세요. 카카오톡 자체 알림은 각 PC에서 카카오톡 설정 → 알림 → 표시 위치 → 화면 우상단으로 선택해야 합니다.

설정은 %LOCALAPPDATA%\GlassDock\topbar.json, 오류 기록은 같은 폴더의 topbar-errors.log에 생성됩니다. 개인 설정·로그·대화 데이터는 이 ZIP에 포함하지 않았습니다.

소스와 전체 문서: https://github.com/SeA9612/windows11-top-bar-mac-UI
릴리즈: https://github.com/SeA9612/windows11-top-bar-mac-UI/releases/tag/v0.1.1


SHA256SUMS.txt contains the SHA-256 checksums for all files in this folder.
